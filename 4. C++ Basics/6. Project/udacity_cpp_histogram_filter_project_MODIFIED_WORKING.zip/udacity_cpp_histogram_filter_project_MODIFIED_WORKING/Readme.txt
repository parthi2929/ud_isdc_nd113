Ensure g++ (mingw) installed.

In Windows, directly execute make.bat

Watch demo here: http://bit.do/my-udacity-cpp-1

The output files are exe, stored in bin folder. 