#ifndef DEBUGGING_HELPERS_H
#define DEBUGGING_HELPERS_H

#include <iostream>
#include <vector>

using namespace std;

void show_grid(vector < vector <float> > grid);

void show_grid(vector < vector <char> > map);

#endif /* DEBUGGING_HELPERS_H */